package class1;
import java.util.*;
class Run
	{
	public static void main(String[]args)
		{
		Scanner input=new Scanner(System.in);
		System.out.println("Enter the length of the rectangular ");
		double l=input.nextDouble();
		System.out.println("Enter the width of the rectangular ");
		double w=input.nextDouble();
		Rectangle obj=new Rectangle();
		obj.setWidth(w);
		obj.setLength(l);
		System.out.println("Area is "+ obj.getArea());
		}
	}